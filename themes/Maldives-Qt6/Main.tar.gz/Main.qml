import QtQuick 2.15
import QtQuick.Layouts 1.15
import QtQuick.Controls 2.15
import QtMultimedia
import SddmComponents 2.0

Rectangle {
    id: container
    width: 640
    height: 480

    LayoutMirroring.enabled: Qt.locale().textDirection == Qt.RightToLeft
    LayoutMirroring.childrenInherit: true

    property int sessionIndex: sessionMenu.sessionIndex

    TextConstants { id: textConstants }

    Connections {
        target: sddm

        onLoginSucceeded: {
            errorMessage.color = "steelblue"
            errorMessage.text = textConstants.loginSucceeded
        }

        onLoginFailed: {
            password.text = ""
            errorMessage.color = "red"
            errorMessage.text = textConstants.loginFailed
        }
        onInformationMessage: {
            errorMessage.color = "red"
            errorMessage.text = message
        }
    }

    Background {
        anchors.fill: parent
        source: Qt.resolvedUrl(config.background)
        fillMode: Image.PreserveAspectCrop
        onStatusChanged: {
            if (status == Image.Error && source != config.defaultBackground) {
                source = config.defaultBackground
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        color: "transparent"

        MouseArea {
            anchors.fill: parent
            onClicked: {
                container.forceActiveFocus()
                if (typeof sessionMenu !== "undefined") {
                    sessionMenu.isExpanded = false
                }
            }
        }

        Clock {
            id: clock
            anchors.margins: 5
            anchors.top: parent.top; anchors.right: parent.right

            color: "white"
            timeFont.family: "Oxygen"
        }

        Image {
            id: rectangle
            anchors.centerIn: parent
            width: Math.max(320, mainColumn.implicitWidth + 50)
            height: Math.max(320, mainColumn.implicitHeight + 50)

            source: "rectangle.png"

            Column {
                id: mainColumn
                anchors.centerIn: parent
                spacing: 12
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    color: "black"
                    verticalAlignment: Text.AlignVCenter
                    height: text.implicitHeight
                    width: parent.width
                    text: textConstants.welcomeText.arg(sddm.hostName)
                    wrapMode: Text.WordWrap
                    font.pixelSize: 24
                    elide: Text.ElideRight
                    horizontalAlignment: Text.AlignHCenter
                }

                Column {
                    width: parent.width
                    spacing: 4
                    Text {
                        id: lblName
                        width: parent.width
                        text: textConstants.userName
                        font.bold: true
                        font.pixelSize: 12
                    }

                    TextBox {
                        id: name
                        width: parent.width; height: 30
                        text: userModel.lastUser
                        font.pixelSize: 14

                        KeyNavigation.backtab: rebootButton; KeyNavigation.tab: password

                        Keys.onPressed: (event) => {
                            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                                password.forceActiveFocus()
                                event.accepted = true
                            }
                        }
                    }
                }

                Column {
                    width: parent.width
                    spacing : 4
                    Text {
                        id: lblPassword
                        width: parent.width
                        text: textConstants.password
                        font.bold: true
                        font.pixelSize: 12
                    }

                    PasswordBox {
                        id: password
                        width: parent.width; height: 30
                        font.pixelSize: 14

                        KeyNavigation.backtab: name; KeyNavigation.tab: loginButton

                        Keys.onPressed: (event) => {
                            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                                sddm.login(name.text, password.text, sessionIndex)
                                event.accepted = true
                            }
                        }
                    }
                }

                Row {
                    spacing: 4
                    width: parent.width / 2
                    z: 100

                    Column {
                        z: 100
                        width: parent.width * 1.3
                        spacing : 4
                        anchors.bottom: parent.bottom

                        Text {
                            id: lblSession
                            width: parent.width
                            text: textConstants.session
                            wrapMode: TextEdit.WordWrap
                            font.bold: true
                            font.pixelSize: 12
                        }

                        Item {
                            id: sessionMenu
                            width: parent.width
                            height: 30
                            z: 100

                            property bool isExpanded: false
                            property string currentSessionName: "Select Session"
                            property int sessionIndex: sessionModel.lastIndex

                            MouseArea {
                                x: -5000
                                y: -5000
                                width: 10000
                                height: 10000
                                visible: sessionMenu.isExpanded
                                z: -1
                                onClicked: {
                                    sessionMenu.isExpanded = false
                                }
                            }

                            Rectangle {
                                anchors.fill: parent
                                color: "white"
                                border.color: "#ccc"
                                border.width: 1

                                Text {
                                    anchors.left: parent.left
                                    anchors.leftMargin: 8
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: sessionMenu.currentSessionName
                                    font.pixelSize: 14
                                    color: "black"
                                }

                                Image {
                                    anchors.right: parent.right
                                    anchors.rightMargin: 8
                                    anchors.verticalCenter: parent.verticalCenter
                                    source: "angle-down.png"
                                    height: parent.height * 0.5
                                    fillMode: Image.PreserveAspectFit
                                }

                                MouseArea {
                                    anchors.fill: parent
                                    onClicked: {
                                        container.forceActiveFocus()
                                        sessionMenu.isExpanded = !sessionMenu.isExpanded
                                    }
                                }
                            }

                            Rectangle {
                                width: parent.width
                                height: Math.min(sessionList.count * 30, 30 * 15)
                                anchors.top: parent.bottom
                                anchors.topMargin: -1
                                color: "white"
                                border.color: "#ccc"
                                border.width: 1
                                visible: sessionMenu.isExpanded
                                clip: true
                                z: 2

                                ListView {
                                    id: sessionList
                                    anchors.fill: parent
                                    model: sessionModel
                                    interactive: count > 15
                                    boundsBehavior: Flickable.StopAtBounds

                                    delegate: Rectangle {
                                        width: sessionList.width
                                        height: 30
                                        color: hoverArea.containsMouse ? "#eeeeee" : "transparent"

                                        Text {
                                            anchors.left: parent.left
                                            anchors.leftMargin: 8
                                            anchors.verticalCenter: parent.verticalCenter
                                            text: model.name
                                            font.pixelSize: 14
                                            color: "black"
                                        }

                                        MouseArea {
                                            id: hoverArea
                                            anchors.fill: parent
                                            hoverEnabled: true
                                            preventStealing: false
                                            onClicked: {
                                                sessionMenu.sessionIndex = index
                                                sessionMenu.currentSessionName = model.name
                                                sessionMenu.isExpanded = false
                                            }
                                        }
                                    }
                                }
                            }

                            Item {
                                Repeater {
                                    model: sessionModel
                                    Item {
                                        Component.onCompleted: {
                                            if (index === sessionModel.lastIndex) {
                                                sessionMenu.currentSessionName = model.name
                                                sessionMenu.sessionIndex = index
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Column {
                        z: 101
                        width: parent.width * 0.7
                        spacing : 4
                        anchors.bottom: parent.bottom
                    }
                }

                Column {
                    width: parent.width
                    z: -1
                    Text {
                        id: errorMessage
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: textConstants.prompt
                        font.pixelSize: 10
                    }
                }

                Row {
                    spacing: 4
                    anchors.horizontalCenter: parent.horizontalCenter
                    z: -1

                    property int btnWidth: Math.max(lblLogin.implicitWidth, lblShutdown.implicitWidth, lblReboot.implicitWidth, 80) + 20

                    Rectangle {
                        id: loginButton
                        width: parent.btnWidth
                        height: 30
                        color: loginMouse.pressed ? "#cccccc" : (loginMouse.containsMouse ? "#e6e6e6" : "#ffffff")
                        border.color: "#aaaaaa"
                        border.width: 1
                        radius: 3
                        activeFocusOnTab: true
                        KeyNavigation.tab: shutdownButton

                        Text {
                            id: lblLogin
                            anchors.centerIn: parent
                            text: textConstants.login
                            color: "black"
                        }

                        MouseArea {
                            id: loginMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            onClicked: sddm.login(name.text, password.text, sessionIndex)
                        }

                        Keys.onPressed: (event) => {
                            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                                sddm.login(name.text, password.text, sessionIndex)
                                event.accepted = true
                            }
                        }
                    }

                    Rectangle {
                        id: shutdownButton
                        width: parent.btnWidth
                        height: 30
                        color: shutdownMouse.pressed ? "#cccccc" : (shutdownMouse.containsMouse ? "#e6e6e6" : "#ffffff")
                        border.color: "#aaaaaa"
                        border.width: 1
                        radius: 3
                        activeFocusOnTab: true
                        KeyNavigation.backtab: loginButton
                        KeyNavigation.tab: rebootButton

                        Text {
                            id: lblShutdown
                            anchors.centerIn: parent
                            text: textConstants.shutdown
                            color: "black"
                        }

                        MouseArea {
                            id: shutdownMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            onClicked: sddm.powerOff()
                        }

                        Keys.onPressed: (event) => {
                            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                                sddm.powerOff()
                                event.accepted = true
                            }
                        }
                    }

                    Rectangle {
                        id: rebootButton
                        width: parent.btnWidth
                        height: 30
                        color: rebootMouse.pressed ? "#cccccc" : (rebootMouse.containsMouse ? "#e6e6e6" : "#ffffff")
                        border.color: "#aaaaaa"
                        border.width: 1
                        radius: 3
                        activeFocusOnTab: true
                        KeyNavigation.backtab: shutdownButton
                        KeyNavigation.tab: name

                        Text {
                            id: lblReboot
                            anchors.centerIn: parent
                            text: textConstants.reboot
                            color: "black"
                        }

                        MouseArea {
                            id: rebootMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            onClicked: sddm.reboot()
                        }

                        Keys.onPressed: (event) => {
                            if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
                                sddm.reboot()
                                event.accepted = true
                            }
                        }
                    }
                }
            }
        }

        Component.onCompleted: {
            if (name.text == "")
                name.focus = true
                else
                    password.focus = true
        }
    }
}
